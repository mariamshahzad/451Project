/*package com.ssaural.samples.excel;

import java.io.file;
import java.ioFileInputStream;
import java.io.IOException;

public class ReadExcel{
	
	public static void main(String[]args)throws IOException {
		File excelFile=new FIle("UMKC Project Data Fall21.xlsx");
		FileInputStrean fis = new FileInputStream(excelFile);
		
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSF Sheet = workbook.getSheetAt(0);
		
		Iterator<Row> rowIt = Sheet.iterator();
		while(rowIt.hasNext()) {
			Row row = rowIt.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			While (cellIterator.hasNext()){
				Cell cell = cellIterator .net();
				System.out.printIn(cell.toString());
			}
		}
	
	
	}
}